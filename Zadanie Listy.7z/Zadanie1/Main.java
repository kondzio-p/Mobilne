package Mobilne.Zadanie1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {

    /**
     * Klasa usuwająca duplikaty
     */
    public static class UsuwaczDuplikatow {

        /**
         * Metoda usuwająca duplikaty z listy
         * 
         * @param list lista, z której usuwamy duplikaty
         * @return zestaw unikalnych elementów
         */
        public static Set<Integer> removeDuplicates(List<Integer> list) {
            return new HashSet<>(list);
        }

        /**
         * Metoda konwertująca Set do listy
         * 
         * @param set zestaw elementów do konwersji na listę
         * @return lista z elementami z zestawu
         */
        public static List<Integer> convertToList(Set<Integer> set) {
            return new ArrayList<>(set);
        }

        /**
         * Metoda konwertująca Set do tablicy
         * 
         * @param set zestaw elementów do konwersji na tablicę
         * @return tablica z elemetami z zestawu
         */
        public static Integer[] convertToArray(Set<Integer> set) {
            return set.toArray(new Integer[0]);
        }
    }

    /**
     * Główna metoda uruchamiająca program
     * 
     * @param args argumenty przekazane do programu (niewykorzystywane)
     */
    public static void main(String[] args) {

        Integer[] tab = {2, 3, 3, 5, 6, 77, 8, 77, 8, 9, 29, 19, 2, 10};

        // Tablica na listę
        List<Integer> list = Arrays.asList(tab);

        // Usunięcie duplikatów z listy
        Set<Integer> uniqueElements = UsuwaczDuplikatow.removeDuplicates(list);

        // Wynik do listy i tablicy
        List<Integer> uniqueList = UsuwaczDuplikatow.convertToList(uniqueElements);
        Integer[] uniqueArray = UsuwaczDuplikatow.convertToArray(uniqueElements);

        System.out.println("Lista z duplikatami: " + list);
        System.out.println("Lista bez duplikatów: " + uniqueList);
        System.out.println("Tablica bez duplikatów: " + Arrays.toString(uniqueArray));
    }
}
