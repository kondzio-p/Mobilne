package mobilne.zadanie;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Przykładowa lista z powtarzającymi się elementami
        Integer[] tab = {1, 2, 3, 4, 3, 2, 5, 6, 7, 5, 8, 9, 10};

        // Konwersja tablicy na listę
        List<Integer> list = Arrays.asList(tab);

        // Usunięcie duplikatów przy pomocy Set
        Set<Integer> uniqueElements = new HashSet<>(list);

        // Konwersja z powrotem do listy lub tablicy (jeśli wymagane)
        List<Integer> uniqueList = new ArrayList<>(uniqueElements);
        Integer[] uniqueArray = uniqueElements.toArray(new Integer[0]);

        // Wyświetlanie wyników
        System.out.println("Lista z duplikatami: " + list);
        System.out.println("Lista bez duplikatów: " + uniqueList);
        System.out.println("Tablica bez duplikatów: " + Arrays.toString(uniqueArray));
    }
}
